package Utility;

public class Constant {

    public static final String URL = "http://ibm-1/VisDSL";

    /*
     * public static final String Username = "rthangam";
     * 
     * public static final String Password = "password";
     */

    public static final String Path_TestData = "D:\\Projects\\POM_FrameWork_VisDSL\\TestData\\";

    public static final String File_TestData = "DataEngine_TestData.xlsx";

}
